package com.example.hosensor;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private SensorManager sensorManager;
    private Sensor temperatureSensor;
    private int counter = 0;

    private TextView dangerTextView;
    private TextView counterTextView;

    private float currentTemperature = Float.MIN_VALUE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button decButton = findViewById(R.id.decButton);
        Button incButton = findViewById(R.id.incButton);

        dangerTextView = findViewById(R.id.dangerTextView);
        counterTextView = findViewById(R.id.counterTextView);
        TextView sensorTextView = findViewById(R.id.sensorTextView);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        temperatureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);

        sensorManager.registerListener(new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                if (sensorEvent.sensor.getType() == Sensor.TYPE_AMBIENT_TEMPERATURE) {
                    currentTemperature = sensorEvent.values[0];
                    sensorTextView.setText(currentTemperature + "°C");
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        }, temperatureSensor, SensorManager.SENSOR_DELAY_NORMAL);

        incButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                counter++;
                counterTextView.setText(String.valueOf(counter) + "°C");
                updateDanger();
            }
        });

        decButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                counter--;
                counterTextView.setText(String.valueOf(counter) + "°C");
                updateDanger();
            }
        });
    }

    private void updateDanger() {
        if (currentTemperature != Float.MIN_VALUE && counter > currentTemperature) {
            dangerTextView.setVisibility(View.VISIBLE);
            //counterTextView.setTextColor(Color.RED);
        } else {
            dangerTextView.setVisibility(View.INVISIBLE);
            counterTextView.setTextColor(Color.BLACK);
        }
    }
}